import React, { useState } from "react";

export default function App() {
  const [area, setArea] = useState(7.9);
  const [areaUnit, setAreaUnit] = useState("Hectars");
  const [lineSpacing, setLineSpacing] = useState(70);
  const [plantSpacing, setPlantSpacing] = useState(0.25);
  const [seedingRate, setSeedingRate] = useState(2);
  const [seedWeight100, setSeedWeight100] = useState(12.1);
  const [lossPercentage, setLossPercentage] = useState(7);
  const [pricePerKg, setPricePerKg] = useState(125);

  const fieldArea = areaUnit === "Hectars" ? area * 10000 : area;
  const lineSpacingM = lineSpacing / 100;
  const plantArea = lineSpacingM * plantSpacing;
  const totalPlants = fieldArea / plantArea;
  const totalSeeds = totalPlants * seedingRate;
  const baseSeedWeightKg = (totalSeeds * seedWeight100) / 1000 / 100;
  const totalSeedWeightKg = baseSeedWeightKg * (1 + lossPercentage / 100);
  const totalCost = totalSeedWeightKg * pricePerKg;

  return (
    <div className="max-w-2xl mx-auto p-6 bg-white rounded-2xl shadow-md space-y-6">
      <h1 className="text-2xl font-bold text-center">Calculadora de Quantidade de Sementes</h1>

      <div className="grid grid-cols-2 gap-4">
        <label>Área</label>
        <input type="number" value={area} onChange={e => setArea(parseFloat(e.target.value))} className="border p-2 rounded" />

        <label>Unidade da Área</label>
        <select value={areaUnit} onChange={e => setAreaUnit(e.target.value)} className="border p-2 rounded">
          <option value="Hectars">Hectares</option>
          <option value="Square meters">Metros quadrados</option>
        </select>

        <label>Espaçamento entre linhas (cm)</label>
        <input type="number" value={lineSpacing} onChange={e => setLineSpacing(parseFloat(e.target.value))} className="border p-2 rounded" />

        <label>Espaçamento entre plantas (m)</label>
        <input type="number" value={plantSpacing} onChange={e => setPlantSpacing(parseFloat(e.target.value))} className="border p-2 rounded" />

        <label>Taxa de sementeira (sementes/covacho)</label>
        <input type="number" value={seedingRate} onChange={e => setSeedingRate(parseFloat(e.target.value))} className="border p-2 rounded" />

        <label>Peso de 100 sementes (g)</label>
        <input type="number" value={seedWeight100} onChange={e => setSeedWeight100(parseFloat(e.target.value))} className="border p-2 rounded" />

        <label>Perdas (%)</label>
        <input type="number" value={lossPercentage} onChange={e => setLossPercentage(parseFloat(e.target.value))} className="border p-2 rounded" />

        <label>Preço por Kg (MT)</label>
        <input type="number" value={pricePerKg} onChange={e => setPricePerKg(parseFloat(e.target.value))} className="border p-2 rounded" />
      </div>

      <div className="mt-6 space-y-2 text-lg">
        <p><strong>Área total:</strong> {fieldArea.toFixed(0)} m²</p>
        <p><strong>Área por planta:</strong> {plantArea.toFixed(3)} m²</p>
        <p><strong>Total de sementes:</strong> {totalSeeds.toFixed(1)} sementes</p>
        <p><strong>Peso das sementes (sem perdas):</strong> {baseSeedWeightKg.toFixed(1)} Kg</p>
        <p><strong>Peso das sementes (com perdas):</strong> {totalSeedWeightKg.toFixed(1)} Kg</p>
        <p><strong>Custo total:</strong> {totalCost.toFixed(1)} MT</p>
      </div>
    </div>
  );
}
