import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import SeedCalculator from './SeedCalculator';

ReactDOM.render(
  <React.StrictMode>
    <SeedCalculator />
  </React.StrictMode>,
  document.getElementById('root')
);
